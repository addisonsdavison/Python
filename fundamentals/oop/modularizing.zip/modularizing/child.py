import parent

# print(locals()) 

